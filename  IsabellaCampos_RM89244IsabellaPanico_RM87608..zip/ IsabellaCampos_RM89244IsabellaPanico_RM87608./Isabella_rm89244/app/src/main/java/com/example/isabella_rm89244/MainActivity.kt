package com.example.isabella_rm89244

import android.app.Activity
import androidx.activity.result.ActivityResult
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import com.example.isabella_rm89244.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var databind: ActivityMainBinding;
    private val jigglypuffAbilities: MutableList<String> = mutableListOf()
    private var pokemon: PokemonProfile? = PokemonProfile("Jigglypuff", "TesteTeste", jigglypuffAbilities)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        databind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(databind.root)
        databind.btnSkills.setOnClickListener { goToSkills() }
    }

    private val register = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.let { data ->
                val skills = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    data.getParcelableExtra("pokemonList", PokemonProfile::class.java)
                } else {
                    data.getParcelableExtra<PokemonProfile>("pokemonList")
                }
                skills?.let {
                    if(skills != null) {
                        pokemon = skills
                    }
                    databind.skillText.text = skills.skills.toString()
                }
            }
        }
    }

    private fun goToSkills() {
        var intent = Intent(this, Skills::class.java);
        intent.putExtra("pokemon", pokemon)
        register.launch(intent)
    }
}
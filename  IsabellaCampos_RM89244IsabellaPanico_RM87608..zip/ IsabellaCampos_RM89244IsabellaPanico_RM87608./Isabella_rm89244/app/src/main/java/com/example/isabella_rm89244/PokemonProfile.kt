package com.example.isabella_rm89244

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PokemonProfile (
    val name: String,
    val description: String,
    val skills: MutableList<String>
) : Parcelable

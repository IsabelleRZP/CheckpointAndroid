package com.example.isabella_rm89244

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.RequiresApi
import com.example.isabella_rm89244.databinding.ActivitySkillsBinding

class Skills : AppCompatActivity() {

    private lateinit var databind: ActivitySkillsBinding

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        databind = ActivitySkillsBinding.inflate(layoutInflater)
        setContentView(databind.root)

        getSkills()
        databind.btnSaveSkills.setOnClickListener {
            Intent().apply {
                putExtra("pokemonList", sendSkills())
                setResult(RESULT_OK, this)
            }
            this.finish()
        }
    }

    private fun getSkills() {
        val pokemon = intent.getParcelableExtra<PokemonProfile>("pokemon")
        databind.switch1.isChecked = pokemon?.skills!!.contains("Cute Charm")
        databind.switch2.isChecked = pokemon?.skills!!.contains("Competitive")
        databind.switch3.isChecked = pokemon?.skills!!.contains("Friend Guard")
        databind.switch4.isChecked = pokemon?.skills!!.contains("Unaware")
    }

    private fun sendSkills(): PokemonProfile? {
        var pokemon = intent.getParcelableExtra<PokemonProfile>("pokemon")
        if(databind.switch1.isChecked && !pokemon!!.skills.contains("Cute Charm")) {
            pokemon?.skills!!.add("Cute Charm")
        } else if (!databind.switch1.isChecked && pokemon!!.skills.contains("Cute Charm")) {
            pokemon?.skills!!.remove("Cute Charm")
        }
        if(databind.switch2.isChecked && !pokemon!!.skills.contains("Competitive")) {
            pokemon?.skills!!.add("Competitive")
        } else if(!databind.switch2.isChecked && pokemon!!.skills.contains("Competitive")) {
            pokemon?.skills!!.remove("Competitive")
        }
        if(databind.switch3.isChecked && !pokemon!!.skills.contains("Friend Guard")) {
            pokemon?.skills!!.add("Friend Guard")
        } else if(!databind.switch3.isChecked && pokemon!!.skills.contains("Friend Guard")) {
            pokemon?.skills!!.remove("Friend Guard")
        }
        if(databind.switch4.isChecked && !pokemon!!.skills.contains("Unaware")) {
            pokemon?.skills!!.add("Unaware")
        } else if(!databind.switch4.isChecked && pokemon!!.skills.contains("Unaware")) {
            pokemon?.skills!!.remove("Unaware")
        }
        return pokemon;
    }
}